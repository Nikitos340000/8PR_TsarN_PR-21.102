package com.example.a8pr_tsarevnikita_pr_21102;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class prodykt extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prodykt);

        ImageButton btnGoToSecAct = (ImageButton) findViewById(R.id.BTR3);

        View.OnClickListener oclBtnGoToSecAct = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(prodykt.this, basket.class);
                startActivity(intent);
            }
        };

        btnGoToSecAct.setOnClickListener(oclBtnGoToSecAct);
        Button btnGoToSecAct2 = (Button) findViewById(R.id.BTR2);

        View.OnClickListener oclBtnGoToSecAct2 = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(prodykt.this, basket.class);
                startActivity(intent);
            }
        };

        btnGoToSecAct.setOnClickListener(oclBtnGoToSecAct);
    }
}